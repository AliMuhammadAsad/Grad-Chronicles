#ifndef NODE_H
#define NODE_H

struct node{
    int val;
    struct node* next;
};

#endif // !NODE_H